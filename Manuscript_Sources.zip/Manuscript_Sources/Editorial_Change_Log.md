# Pre-deposit editorial revision R2 — 21 September 2026

The mathematical ceiling remains 18674384228461/125000000000000.
Public version remains 1.0, assuming no earlier version of this same time-zero paper has been published.

Changes: contextual previous-bound paragraph; Platt–Trudgian 0.2 corollary; exact Gomila and Gordon values; pinned repository citations; reference-status and proof-dependence distinction; conventional abstract and main theorem; explicit normalisation and cutoff definitions; numbered mathematical signposts; dependency map and roadmap; terminology and cross-references; PDF metadata; data/AI disclosure and journal-review scope.

The historical claim “developed independently” has not been inserted. The supplied project history records consultation of Gordon. Independence of the present proof inputs is the narrower claim stated. Gomila is cited through a verified author/repository source, not an unlocated arXiv identifier.

The scientific evidence ZIP and deposit checker are unchanged. The final revision report records the exact hashes and all checks performed. No end-to-end numerical replay was performed as part of this editorial revision.
