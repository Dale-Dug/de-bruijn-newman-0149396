# Editorial review and remaining submission checks

## Changes completed

The paper now cites the closest public preprints for context, identifies its published proof inputs separately, and avoids claiming to improve only on 0.22. The exact Gordon ceiling is preserved, and the Gomila reference identifies the verified repository manuscript rather than an unlocated arXiv item. The Platt–Trudgian 0.2 corollary was added.

The manuscript has a conventional abstract, main theorem, defined normalisation/cutoff, labelled sign lemmas and joint-source theorem, internal section references, a dependency table, complete bibliographic entries, PDF metadata and an author/AI disclosure. The foundations retain their reproduced mathematical text; the cover supplies a clearer reading map.

## Provenance wording

No claim of development without knowledge of concurrent work is added. The visible project history includes reading Gordon, evaluating a corollary of his claimed results, rejecting that route as the final publication's basis, and then producing the own-source chain. This supports distinguishing proof dependence from awareness or historical independence. It does not warrant an unqualified 'developed independently' declaration. The manuscript states the dependency distinction and acknowledges awareness.

## Sources checked

Polymath: arXiv:1904.12438v2 and published bibliographic data, Λ ≤ 0.22.
Platt–Trudgian: arXiv:2004.09765v1, Theorem 1 and Corollary 2 (Λ ≤ 0.2).
Gomila: author's 19 August 2026 announcement, repository README and CITATION.md; exact bound 893927/5000000. Pinned revision a74738deb6d5e0f76887cb36901da08b68dca705. A corresponding arXiv identifier was not located.
Raymond: supplied original manuscript and Reach_Law_Row_Survey_DRAFT_v0_2.pdf bibliography report 8 September 2026, DOI 10.5281/zenodo.22626161. Live Zenodo/DOI/API retrieval failed; the date is source-supported, not newly verified from the landing page.
Gordon: manuscript, VERIFICATION.md and current revision 64c47f2db67288beb62c24d7a0f7aedd645dc4b3. Exact bound 3885632262767861213460393068710302759/24646172707879668706230182733520000000. Partial Lean formalisation retains explicit analytic assumptions; the repository says not externally peer reviewed.

## What has not been independently established in this editorial pass

This is not a fresh mathematical validation of the analytic extensions, a full numerical replay, or external peer review. The continued large-height approximation, uniform derivative remainder, source-to-code correspondence, first-contact compactness at early time and collision treatment remain appropriate referee audit targets. No gap was silently supplied by citation or assumption. Preserving numerical bytes does not prove that the represented mathematics is correct.

The paper is prepared for journal review; journal acceptance or complete independent correctness is not asserted. The author must review the mathematical claims, provenance wording and licence decision. The existing software-licence question is left explicit rather than assigned without approval.

## Public version

Use version 1.0 if this separate time-zero paper has not yet been published. This revision is R2 of the prepared manuscript, not version 1.1 of a public record. Do not create a duplicate if the same time-zero manuscript already has a published record.
