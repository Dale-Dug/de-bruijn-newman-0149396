# Editorial revision R2 — use this package in place of the earlier draft

The prepared public version remains 1.0. Upload all 12 individual files in `UPLOAD/`; use the revised main paper as default preview. The exact mathematical ceiling and `Proof_and_Replay.zip` are unchanged. Contextual references and metadata are now consistent with the revised Introduction.

Do not mix the old PDFs, source ZIP or outer checksums with these revised files. The new integrity check must pass as a set. Historical mathematical replay receipts remain inside the unchanged evidence archive; the R2 validation records only the checks actually performed for this edit.

Read `Editorial_Review.md` and confirm the author disclosure, source-supported original publication date and licence scopes before publishing.

# Deposit instructions and version decision

## Recommended structure: new preprint, version 1.0

This is now a separate time-zero paper, not merely a changed numerical
certificate for the original fixed-time atlas manuscript. The old record
(10.5281/zenodo.22626161) remains the publication of that earlier argument.
The present sources re-establish the necessary wall and probe estimates and
do not assume the old narrow strip or final-time atlas.

Create ONE new Zenodo record containing this paper, the analytic foundations
and all its reproducibility materials. Cite the old DOI using **Cites**.
Do not publish identical copies as both an unrelated new record and a new
version of the old one.

This recommendation differs from the earlier 0.159863 update plan because that
earlier corollary explicitly depended on the old narrow strip. The present
time-zero construction has a different starting theorem and dependency chain.

If this exact time-zero paper has already been deposited in an unobserved
record, use New version of THAT record instead. Do not create a duplicate.
The live old record could not be retrieved in this audit; current draft status,
licence settings and any unreported later version were not independently observed.


\newpage

## The 12 public files

    Analytic_Foundations.pdf
    CITATION.cff
    Correlated_Translated_Probes.pdf
    Correlated_Translated_Probes.tex
    LICENSES_AND_RIGHTS.md
    Manuscript_Sources.zip
    Proof_and_Replay.zip
    README.md
    Release_Manifest.json
    SHA256SUMS.txt
    Verification_Guide.pdf
    Verify_Deposit.py

Upload all twelve. The outer release ZIP and AUTHOR folder are transport/instructions, not additional public evidence files.

## Before uploading

1. Keep the original project archives and old published record unchanged.
   This deposit is a publication package, not a replacement for project history.
2. Extract the outer ZIP normally. Upload the individual files in `UPLOAD/`.
   Do not upload `AUTHOR/`, the outer transport ZIP, PDF renders or working logs.
3. Review the main paper, verification scope, author identity, assistance
   statement and the licence scopes. No affiliation, funding or journal
   acceptance has been invented.
4. Run `python3 Verify_Deposit.py --check-only` in `UPLOAD/` for a quick integrity
   check. This does NOT perform numerical verification.
5. The complete mathematical replay is documented in Verification_Guide.pdf.
   The supplied new receipt records what was actually regenerated.

## Zenodo steps

1. Sign in and choose **New upload**.
2. Select **Preprint** as the resource type. Set **Version: 1.0**.
3. In the DOI field, select **No** for an existing DOI for THIS new object.
   Reserve its DOI with **Get a DOI now!**. Do not enter the earlier paper's DOI.
4. Upload every file in `UPLOAD/`. Wait for all uploads to complete.
   Select Correlated_Translated_Probes.pdf as the default preview.
5. Paste the title, creator, ORCID, abstract, keywords and related identifier
   from Fields_to_Copy.txt. Use the actual first-public-release date.
6. Select the author-approved licence or mixed licences with their correct
   scopes; retain the third-party notices. Do not treat the paper's licence
   as a new blanket software licence.
7. Add the earlier DOI with relation **Cites** (or the displayed equivalent
   "references"). This points from the new record to the old paper.
8. Preview the landing page. Confirm the title, bound 0.149396, exact fraction,
   version 1.0, author, readable first PDF and complete file list.
9. Publish only after that review. A reserved DOI becomes registered when
   the record is published. This package has not created or published a draft.

## DOI inside the PDF

The files intentionally contain no fake or reused new DOI. Zenodo's landing
page and exported citation can provide the assigned identifier without editing
the PDF. This is the simplest path and keeps the delivered file hashes valid.

To print the reserved DOI inside the document before publishing, edit only the
publication sources, recompile and regenerate the RELEASE manifest/checksums.
Do not edit the immutable scientific source ZIP or its manifests. The included
author-side reseal tool can rebuild the outer deposit manifest after a deliberate
publication-only edit; it does not rerun or certify mathematics.

## Future versions

Use New version of this new paper's record for a corrected proof, changed
numerical witness, new endpoint or improved analysis. An illustrative scheme is
1.0 for this first release, 1.1 for a substantive revision and 2.0 for a major
revision. Zenodo's sequence and the human version label are separate concepts.

Metadata-only corrections do not require a new file version. For mathematical
or numerical changes, preserve the old version and publish a changelog.
Do not silently replace historical scientific evidence.

Zenodo assigns a different version DOI to each public version and retains a
concept DOI for the record family. Cite a version DOI for reproducible theorem
claims. Do not construct DOI suffixes yourself.

## Link back from the old record

After publication, the old record may receive a metadata-only related identifier
to the new version DOI using **IsReferencedBy**, or a brief note directing readers
to the separate time-zero paper. Keep the old title, bound and files historically
accurate. The old record is not being withdrawn or relabelled as this new proof.

## Official guidance checked on 21 September 2026

- https://help.zenodo.org/docs/deposit/manage-versions/
- https://zenodo.org/help/versioning
- https://help.zenodo.org/docs/deposit/create-new-upload/
- https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/
- https://help.zenodo.org/docs/deposit/manage-files/
- https://help.zenodo.org/docs/deposit/describe-records/licenses/

Zenodo's help pages describe different limits for short-window edits to published
files. This release does not rely on that facility: use a new record for the new
paper and explicit future versions for changed proof files.
