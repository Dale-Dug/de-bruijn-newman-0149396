# Correlated translated probes: Lambda < 0.149396

Dale James Raymond — ORCID 0009-0001-1682-8529  
Prepared release: **1.0**, 21 September 2026

Exact ceiling:
```
Lambda <= 18674384228461/125000000000000
       = 0.149395073827688
       < 0.149396.
```

## Start here
Read `Correlated_Translated_Probes.pdf`, then `Analytic_Foundations.pdf`.
The latter includes the written approximation, wall, source and global
comparison arguments. `Verification_Guide.pdf` states execution and trust scope.

`Proof_and_Replay.zip` is complete for this time-zero proof. It includes the
unchanged numerical source, embedded parents and runtime, fresh evidence,
the exact final-comparison layer, and default full replay.
The 27 evidence volumes for the author's old fixed-time paper are **not required**.

## Integrity only
From the directory of the public files:
```
python3 Verify_Deposit.py --check-only
```
This checks file identity, not mathematical correctness.

## Full numerical regeneration
Use CPython 3.13 on Linux x86_64:
```
python3.13 Verify_Deposit.py --replay --output ../replay_0149396
```
Output must be outside the deposit and new/empty. The default runs every
numerical producer; no network or separately installed numerical Python
library is required. Do not disable assertions.

Expected final marker: `ZENODO_FULL_NUMERICAL_REPLAY_PASS`.
The final exact endpoint is the fraction above. Intermediate source-stage
markers retain their historical endpoint and are followed by the final layer.

## Verification boundary
Both transcendental lanes use Arb/FLINT, with different precision/construction
choices, not independent libraries. Exact comparison and history checking use
integer/rational arithmetic. Written analytic deductions are not formalised
in a proof assistant. The original published Platt–Trudgian finite-RH
computation is cited, not repeated. No unfinished Target-A hypothesis or
competing preprint's functional theorem is a premise.

The work has not undergone external peer review. This is not a proof of
Lambda < 0.09 or RH, and no exhaustive world-record/priority claim is made.

## Previous and concurrent work
Published benchmarks include Polymath's Λ ≤ 0.22 and the Platt–Trudgian corollary Λ ≤ 0.2. Subsequent public preprints report Gomila's Λ ≤ 0.1787854 (August 2026), Raymond's Λ < 0.163297 (Zenodo, September 2026), and Gordon's Λ ≤ 0.157656619095490606768… (GitHub, September 2026). These recent preprints are cited for context, not as proof inputs. Gordon's Lean companion is a partial formalisation with explicit analytic hypotheses. The present proof does not use the upper bounds, new estimates or numerical certificates from those preprints. No claim of historical priority or of development without awareness of concurrent work is made.

See the main manuscript for precise bibliographic entries and pinned revisions. The earlier author deposit is dated 8 September 2026 in the supplied project bibliography; the live Zenodo metadata was not retrievable during this editorial pass.

## Editorial revision R2
This is an editorial revision before first public deposit. The mathematical bound, numerical sources, exact histories and complete `Proof_and_Replay.zip` are unchanged. The publication documents, references and outer manifests have been updated. No new numerical replay is claimed for this editorial pass.

## Citation and licences
Use the actual version DOI assigned to this new record. No new DOI is invented
inside these files. The earlier DOI 10.5281/zenodo.22626161 is prior work and
must not be used as this paper's identifier.
See `CITATION.cff` and `LICENSES_AND_RIGHTS.md`.
