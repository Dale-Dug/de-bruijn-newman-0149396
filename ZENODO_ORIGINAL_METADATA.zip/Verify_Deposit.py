#!/usr/bin/env python3
"""Integrity-check this deposit, optionally regenerate its complete numerical proof."""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, stat, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parent
REQUIRED={
    "Correlated_Translated_Probes.pdf","Correlated_Translated_Probes.tex",
    "Analytic_Foundations.pdf","Manuscript_Sources.zip","Proof_and_Replay.zip",
    "Verification_Guide.pdf","README.md","Verify_Deposit.py",
    "LICENSES_AND_RIGHTS.md","CITATION.cff"
}
def need(x,msg):
    if not x: raise ValueError(msg)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):h.update(b)
    return h.hexdigest()
def verify():
    doc=json.loads((ROOT/"Release_Manifest.json").read_text())
    need(doc.get("schema")=="ZENODO_0149396_DEPOSIT_V1","Wrong deposit manifest schema")
    need(doc.get("upper_exact")=="18674384228461/125000000000000","Wrong theorem identifier")
    need(doc.get("public_version")=="1.0","Wrong prepared version")
    need(set(doc["files"])==REQUIRED,"Incomplete or unexpected deposit file list")
    for name,rec in doc["files"].items():
        p=ROOT/name
        need(p.resolve().is_relative_to(ROOT) and p.is_file() and not p.is_symlink(),"Unsafe/missing: "+name)
        need(p.stat().st_size==rec["bytes"] and sha(p)==rec["sha256"],"Changed file: "+name)
    lines=(ROOT/"SHA256SUMS.txt").read_text().splitlines()
    checks={}
    for line in lines:
        digest,name=line.split("  ",1)
        need(name not in checks,"Duplicate checksum")
        checks[name]=digest
    need(set(checks)==REQUIRED|{"Release_Manifest.json"},"Checksum catalogue scope")
    for name,digest in checks.items():
        need(sha(ROOT/name)==digest,"Checksum mismatch: "+name)
    return len(REQUIRED)+2
def safe_extract(src,dest):
    dest.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(src) as z:
        seen=set()
        for i in z.infolist():
            need(i.filename not in seen,"Duplicate archive member");seen.add(i.filename)
            need((dest/i.filename).resolve().is_relative_to(dest.resolve()),"Unsafe archive member")
            need(not stat.S_ISLNK(i.external_attr>>16),"Archive symlink")
        need(z.testzip() is None,"ZIP CRC failure")
        z.extractall(dest)
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check-only",action="store_true")
    g.add_argument("--replay",action="store_true")
    ap.add_argument("--output",type=Path)
    a=ap.parse_args()
    n=verify()
    print("ZENODO_DEPOSIT_INTEGRITY_PASS",n,flush=True)
    if a.check_only:return
    need(a.output is not None,"--output required")
    out=a.output.resolve()
    need(not out.is_relative_to(ROOT),"Output must be outside the immutable deposit")
    need(not out.exists() or not any(out.iterdir()),"Use a new empty output directory")
    out.mkdir(parents=True,exist_ok=True)
    safe_extract(ROOT/"Proof_and_Replay.zip",out/"supplement")
    supplement=out/"supplement/Proof_and_Replay"
    subprocess.run([sys.executable,"-B",str(supplement/"REPLAY.py"),
                    "--output",str(out/"execution")],check=True)
    r=json.loads((out/"execution/COMPLETE.json").read_text())
    need(r.get("marker")=="ZENODO_FULL_NUMERICAL_REPLAY_PASS" and r.get("PASS") is True,
         "No complete default replay")
    need(r.get("upper_exact")=="18674384228461/125000000000000","Unexpected final endpoint")
    need(verify()==n,"Deposit changed during replay")
    print("ZENODO_DEPOSIT_FULL_REPLAY_PASS",r["upper_exact"])
if __name__=="__main__":
    if not __debug__:raise RuntimeError("Checks must not be disabled")
    main()
